console.log("Hello from secure CI/CD pipeline!");
